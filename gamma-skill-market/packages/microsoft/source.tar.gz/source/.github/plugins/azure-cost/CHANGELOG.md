# Changelog

## 1.0.5

- chore: add telemetry disclosure for azure-cost plugin ([#3296](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3296))

## 1.0.4

- feat: add standalone telemetry reporter bootstrap ([#3273](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3273))

## 1.0.3

- fix: run Windows telemetry hooks with PowerShell ([#3263](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3263))

## 1.0.2

- fix: use session_start telemetry event ([#3245](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3245))

## 1.0.1

- chore: add security warning in azure-cost ([#3247](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3247))

## 1.0.0

- feature: add standalone Azure Cost plugin ([#3151](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3151))
