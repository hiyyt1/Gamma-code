# Changelog

## 1.2.80

- fix: appinsights-instrumentation prerequisite ([#3292](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3292))

## 1.2.79

- fix: distro-aware SSH probe for Ubuntu 24.04 ([#3294](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3294))

## 1.2.78

- fix: mcp enable command ([#3290](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3290))

## 1.2.77

- use consistent line ending ([#3313](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3313))

## 1.2.76

- docs: add telemetry disclosure to azure-skills README ([#3305](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3305))

## 1.2.75

- feat: add standalone telemetry reporter bootstrap ([#3273](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3273))

## 1.2.74

- fix: azure-reliability instruction ([#3291](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3291))

## 1.2.73

- fix: run Windows telemetry hooks with PowerShell ([#3263](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3263))

## 1.2.72

- fix: handle uv.lock samples behind private package index in Foundry hosted agent quick start ([#3264](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3264))

## 1.2.71

- feature: add discover-azure-skills skill ([#3053](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3053))

## 1.2.70

- fix: use session_start telemetry event ([#3245](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3245))

## 1.2.69

- Document npx usage in plugin README and their security implication ([#3240](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3240))

## 1.2.68

- feature: add standalone Azure Cost plugin ([#3151](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3151))

## 1.2.67

- fix: bump plugin versions for hook changes ([#3227](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3227))

## 1.2.66

- refactor: clarify evidence checks in hosted-agent validation rules ([#3236](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3236))

## 1.2.65

- feat: add scoped hosted-agent validation rules ([#3235](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3235))

## 1.2.64

- feat: report session start telemetry ([#3216](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3216))

## 1.2.63

- feat: add Foundry IQ skills plugin ([#3209](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3209))

## 1.2.62

- feature: new onboard-plugin skill ([#3191](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3191))

## 1.2.61

- fix: decode Cursor telemetry input as UTF-8 ([#3214](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3214))

## 1.2.60

- feat: expand Foundry validation rules ([#3192](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3192))

## 1.2.59

- feat(microsoft-foundry): add MCP-backed agent insights workflow ([#3207](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3207))

## 1.2.58

- feature: add azure-local-skills plugin (standard + multi-rack) ([#2163](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2163))

## 1.2.57

- feat: improve Foundry validation reports ([#3170](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3170))

## 1.2.56

- chore: foundry skill improvements on sample selection, model query, trigger words, and evals ([#3177](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3177))

## 1.2.55

- fix: use TCP checks for local agent readiness in Foundry Skill ([#3169](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3169))

## 1.2.54

- fix: refine Foundry agent setup and deployment guidance ([#3165](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3165))

## 1.2.53

- fix: remove unnecessary trigger phrase in azure-compliance skill body ([#3118](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3118))

## 1.2.52

- fix: normalize Cursor telemetry input ([#3158](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3158))

## 1.2.51

- feat: add Azure Functions hosting and cold-start guidance ([#3122](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3122))

## 1.2.50

- fix: improve langchain-azure-ai migration ([#3160](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3160))

## 1.2.49

- fix: add cross-platform Cursor telemetry runner ([#3146](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3146))

## 1.2.48

- fix: restore Cursor telemetry reporting ([#3141](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3141))

## 1.2.47

- chore: clean duplicate trigger words in Foundry Skill description ([#3145](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3145))

## 1.2.46

- fix: deduplicate events from track-telemetry script ([#3142](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3142))

## 1.2.45

- chore: bring back additional filter for multiple plugins ([#3131](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3131))

## 1.2.44

- feat: Add more validate rules ([#3130](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3130))

## 1.2.43

- feat: route explicit Foundry agent validation ([#3128](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3128))

## 1.2.42

- Add agent validation rules ([#3127](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3127))

## 1.2.41

- feat: add Foundry agent validation skill entry point ([#3115](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3115))

## 1.2.40

- fix: role ([#3114](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3114))

## 1.2.39

- misc: revert additional path pattern for kusto graph plugin ([#3108](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3108))

## 1.2.38

- feat: Added Referenced Workloads Updates to Azure Enterprise Infra Planner Skills (feature: Referenced Workloads) ([#3094](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3094))

## 1.2.37

- chore: log plugin version ([#3102](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3102))

## 1.2.36

- refactor: remove duplicate content from Foundry skill description ([#3104](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3104))

## 1.2.35

- fix: detect Cursor client in telemetry hook via cursor_version field ([#3100](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3100))

## 1.2.34

- fix: track reference file reads regardless of plugin catalog name ([#3096](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3096))

## 1.2.33

- Update outdated runtime references in plugin skills to latest LTS versions ([#3011](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3011))

## 1.2.32

- feat: replace azure-diagnostics AKS pod-failure evidence bundle with a script ([#2933](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2933))

## 1.2.31

- fix: mark Azure diagnostics shell script executable ([#3029](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3029))

## 1.2.30

- feature: extend telemetry for new plugins ([#3059](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3059))

## 1.2.29

- refactor: improve re-host scenario in foundry skill ([#3063](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3063))

## 1.2.28

- fix: improve Foundry Copilot app preflight ([#3061](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3061))

## 1.2.27

- refactor: improve azd sample selection guidance and agent creation workflow in foundry skill ([#3056](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3056))

## 1.2.26

- chore: remove unused py sdk ref and add auth best practices ref in foundry skill's skill.md ([#3041](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3041))

## 1.2.25

- fix: mark azure app onboard shell script executable ([#3026](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3026))

## 1.2.24

- Add app-deploy workflow to the azure-kubernetes skill ([#2696](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2696))

## 1.2.23

- feat(azure-diagnostics): add run-ig script for Inspektor Gadget invocation ([#2934](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2934))

## 1.2.22

- fix: mark azure quotas shell script executable ([#3027](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3027))

## 1.2.21

- fix: mark azure-validate shell scripts executable ([#3028](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3028))

## 1.2.20

- fix: mark azure-deploy shell scripts executable ([#3030](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3030))

## 1.2.19

- fix: mark azure-prepare shell script executable ([#3032](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3032))

## 1.2.18

- fix: mark microsoft-foundry shell scripts executable ([#3031](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3031))

## 1.2.17

- chore: clean out-of-date descriptions in foundry skill ([#3019](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3019))

## 1.2.16

- fix: disambiguate azure-prepare/deploy and azure-app-onboard ([#3036](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3036))

## 1.2.15

- feat: replace azure-diagnostics messaging connectivity probe with a script ([#2932](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2932))

## 1.2.14

- feat: extract azure-diagnostics dump-everything blocks into scripts ([#2935](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2935))

## 1.2.13

- fix: resolve Claude hooks.json validation error and add telemetry debug logging ([#3021](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3021))

## 1.2.12

- feat: support activity protocol in Foundry skill ([#3008](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/3008))

## 1.2.11

- feat: replace azure-diagnostics AKS baseline sweep with aks-baseline script ([#2936](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2936))

## 1.2.10

- feat: drive azure-validate steps via workflow.ps1 script ([#2969](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2969))

## 1.2.9

- chore: reuse hooks by building for all plugins ([#2991](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2991))

## 1.2.8

- feat: add Foundry skill dependency check and setup scripts ([#2956](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2956))

## 1.2.7

- chore: bump all skill versions ([#2985](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2985))

## 1.2.6

- feature: multi plugin project structure ([#2872](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2872))

## 1.2.5

- fix: auto-install microsoft-foundry plugin in Copilot app ([#2954](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2954))

## 1.2.4

- feat: support re-host scenario ([#2955](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2955))

## 1.2.3

- feat: create toolbox skill for foundry agent ([#2921](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2921))

## 1.2.2

- feature: Introduce azure-app-onboard skill along with azure-app-onboard-prereq + vally tests ([#2938](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2938))

## 1.2.1

- fix: azure-validate eval failures (deploy-intent gating + tool-call-match grading) ([#2928](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2928))

## 1.2.0

- fix: unify plugin and changelog versioning ([#2927](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2927))

## 1.1.105

- Fix ambiguous file path example ([#2893](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2893))

## 1.1.104

- feat: Migrate VM Troubleshooter workflow to azure-diagnostics ([#2859](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2859))

## 1.1.103

- feat: set azd user agent env ([#2882](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2882))

## 1.1.102

- fix: split prompt-agent tool references into tools/prompt-agent/ ([#2857](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2857))

## 1.1.101

- feat: replace azure-validate AZCLI/Bicep validation steps with a shared script ([#2856](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2856))

## 1.1.100

- feat: replace azure-validate Aspire Functions secret-storage scan with a script ([#2854](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2854))

## 1.1.99

- feat: replace azure-validate Aspire ACA env-var setup with a script ([#2855](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2855))

## 1.1.98

- feat: script-ify Terraform validation preflight sequence (azure-validate) ([#2862](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2862))

## 1.1.97

- fix: improve canvas-entry gate logic and add plugin-contributed extension detection ([#2866](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2866))

## 1.1.96

- fix(microsoft-foundry): support user-entra-token auth for incoming a2a ([#2858](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2858))

## 1.1.95

- feature: retire azure-rbac skill ([#2779](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2779))

## 1.1.94

- fix(microsoft-foundry): hosted agents call incoming A2A agent ([#2846](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2846))

## 1.1.93

- feat: align the Microsoft Foundry skill with the latest azd behavior ([#2844](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2844))

## 1.1.92

- feat: add cicd sub skill ([#2838](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2838))

## 1.1.91

- fix: clarify canvas-first reminder ([#2837](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2837))

## 1.1.90

- chore: improve agent instruction and quick start ([#2768](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2768))

## 1.1.89

- fix: remove azd init from Foundry agent creation ([#2812](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2812))

## 1.1.88

- feat: update invocations_ws skill for GA and path-based routing ([#2807](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2807))

## 1.1.87

- eval: migrate azure-compute integration tests to vally eval suite ([#2596](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2596))

## 1.1.86

- fix: use proper tool to execute query in Azure SQL Server ([#2772](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2772))

## 1.1.85

- feat: add canvas-first entry gate for Foundry agent creation ([#2775](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2775))

## 1.1.84

- feature: retire azure-hosted-copilot-sdk skill ([#2556](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2556))

## 1.1.83

- feat: capture and report skill version in telemetry hooks ([#2763](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2763))

## 1.1.82

- eval: migrate azure-prepare integration tests to vally eval suites ([#2721](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2721))

## 1.1.81

- feat: support foundry routine and add it as a sub-skill ([#2743](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2743))

## 1.1.80

- fix: correct toolbox reference docs from live testing ([#2755](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2755))

## 1.1.79

- fix(microsoft-foundry): vnet ([#2754](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2754))

## 1.1.78

- fix: restructure and update skill reference docs for hosted agent creation ([#2737](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2737))

## 1.1.77

- fix(microsoft-foundry): sync latest azd contract and schema ([#2722](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2722))

## 1.1.76

- feat: add guardrails reference docs for hosted agent creation ([#2731](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2731))

## 1.1.75

- fix: Get hooks working in Copilot again ([#2719](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2719))

## 1.1.74

- feat: improve foundry skill in more real user scenarios. ([#2705](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2705))

## 1.1.73

- feat: add skill related knowledge into foundry skill ([#2664](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2664))

## 1.1.72

- fix(microsoft-foundry): improve quick start provision and local run polling ([#2694](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2694))

## 1.1.71

- fix: add Network Isolation Errors hint to microsoft-foundry SKILL.md ([#2685](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2685))

## 1.1.70

- Enhance FAOS documentation and fix evaluator contract issues ([#2637](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2637))

## 1.1.69

- feat: improve the hosted agent getting started with coding ([#2610](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2610))

## 1.1.68

- feat: add python-appservice-deploy skill for Python/Flask/Django/FastAPI on App Service ([#2487](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2487))

## 1.1.67

- feat(azure-compute): add VM creation workflow with approval gate before deploy ([#2297](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2297))

## 1.1.66

- feat: (azure-cost) add storage optimization guide and fix token limit ([#2554](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2554))

## 1.1.65

- eval: migrate infra-planner tests to Vally ([#2483](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2483))

## 1.1.64

- Optimize FAOS preparation and clarify evaluator documentation ([#2482](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2482))

## 1.1.63

- Fix: hard gate deployment phase for infra-planner skill ([#2427](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2427))

## 1.1.62

- fix azure-upgrade: improve Java Azure SDK BOM migration reliability ([#2270](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2270))

## 1.1.61

- docs: rename AI Toolkit to Foundry Toolkit for VSCode in microsoft-foundry skill ([#2429](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2429))

## 1.1.60

- Refresh toolbox skills and add Foundry tool catalog (connector) reference ([#2384](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2384))

## 1.1.59

- azure-kubernetes: add VPA and pod rightsizing routing triggers ([#2391](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2391))

## 1.1.58

- feat(azure-kubernetes): Update constraint spec references to match what Deployment Safeguards enforces ([#1976](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1976))

## 1.1.57

- rename Foundry RBAC roles ([#2281](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2281))

## 1.1.56

- Add insights into the infra planner skill ([#2345](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2345))

## 1.1.55

- Add invocations_ws sub-skill to microsoft-foundry ([#2388](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2388))

## 1.1.54

- Clarify FAOS optimization guidance and improve evaluator contracts leveraging azd ([#2383](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2383))

## 1.1.53

- Add azure-reliability — Azure App Service reliability reference ([#2242](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2242))

## 1.1.52

- feature: Move quota workflow to a script ([#2360](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2360))

## 1.1.51

- fix: toolbox skill invocation and foundry samples path ([#2389](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2389))

## 1.1.50

- feat: support direct code deployment ([#2362](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2362))

## 1.1.49

- Clarify FAOS optimization guidance and improve evaluator contracts ([#2286](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2286))

## 1.1.48

- Add: Fine-tuning sub-skill for microsoft-foundry plugin ([#1995](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1995))

## 1.1.47

- updated plugin.json to skip default hooks.json discovery from vscode ([#2308](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2308))

## 1.1.46

- feat(azure-diagnostics/inspektor-gadget): Use correct filter for tcpdump gadget ([#2292](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2292))

## 1.1.45

- feat(microsoft-foundry): add Tracing Insights API skill for automated anomaly detection ([#2276](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2276))

## 1.1.44

- fix(microsoft-foundry): update integrate toolbox into hosted-agent flow ([#2264](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2264))

## 1.1.43

- Clarify FAOS optimization guidance and custom evaluator contracts ([#2251](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2251))

## 1.1.42

- Add azure-reliability skill (Functions) ([#2241](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2241))

## 1.1.41

- azure-diagnostics: Add Inspektor Gadget Reference ([#1961](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1961))

## 1.1.40

- fix: update foundry-agent invoke skill for invocations protocol ([#2154](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2154))

## 1.1.39

- ci(eval): migrate to Vally eval framework with v0.4.0 features ([#1912](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1912))

## 1.1.38

- Fix broken VPA installation link in azure-aks-vpa.md ([#2178](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2178))

## 1.1.37

- fix: improve azure-hosted-copilot-sdk routing for codebase-detection scenarios ([#1857](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1857))

## 1.1.36

- FAOS optimize preparation skill ([#2174](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2174))

## 1.1.35

- Add Spring Boot to Azure Container Apps migration skill ([#1569](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1569))

## 1.1.34

- Gap-5: App Service Operate (B+ → A) — SKU selection, custom domains, networking ([#1639](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1639))

## 1.1.33

- azure-upgrade: add Redis (ACR/OSS and ACRE) -> AMR migration scenarios ([#2159](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2159))

## 1.1.32

- feature: Feature/azure compute/enablemachinemanagement ([#2069](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2069))

## 1.1.31

- Gap-8: App Service Migrate (F → A) — Beanstalk + Heroku + App Engine migration guides ([#1633](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1633))

## 1.1.30

- Gap-10: Container Apps Observe (B → A) — Observability playbook + Dapr tracing ([#1642](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1642))

## 1.1.29

- fix(app-service-templates): address review feedback — discoverability, auth IaC, token refresh, source splits ([#1635](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1635))

## 1.1.28

- Add missing instructions for terraform two-phase pre deploy check ([#2138](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2138))

## 1.1.27

- update the path in script to support claude marketplace file refs ([#2122](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2122))

## 1.1.26

- Add private-network sub-skill for Foundry VNet deployment ([#2073](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2073))

## 1.1.25

- Eval suite renaming and multiple env & agent folder support. ([#2092](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2092))

## 1.1.24

- fix: update toolbox sample link ([#2078](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2078))

## 1.1.23

- Add continuous-eval observe ref for Foundry agent Monitoring ([#1733](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1733))

## 1.1.22

- Gap-6: App Service Diagnose (B → A) — Dedicated troubleshooting guide ([#1640](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1640))

## 1.1.21

- fix: Remove context7 MCP server from plugin config ([#2100](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2100))

## 1.1.20

- feat: Extend `azure-upgrade` skill by adding workflow for migrating legacy Azure SDKs for Java to latest modern ones ([#1901](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1901))

## 1.1.19

- Add entra-agent-id skill ([#2033](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2033))

## 1.1.18

- fix: strengthen azure-resource-lookup routing for web app/website prompts ([#2006](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2006))

## 1.1.17

- Move Azure Messaging Troubleshooting Info To New Directory ([#1986](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1986))

## 1.1.16

- Ask agent to remove stale IaC after potential conversion ([#2032](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2032))

## 1.1.15

- Gap-3: Container Apps Operate (C → A) — Revisions, day-2 ops, networking ([#1637](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1637))

## 1.1.14

- feat: generate CHANGELOG.md at build time from git history ([#2068](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2068))

## 1.1.13

- Extend azure-cloud-migrate skill with AWS Fargate to Container Apps scenario ([#1534](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1534))

## 1.1.12

- chore: update post-deployment rbac assignment logic ([#2057](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2057))

## 1.1.11

- fix: Add Foundry Toolbox integration to hosted agent create skill ([#2035](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2035))

## 1.1.10

- Remove hardcoded Azure Functions templates, use MCP tool ([#1949](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1949))

## 1.1.9

- fix: strengthen azure-storage routing for storage tiers informational prompts ([#2008](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2008))

## 1.1.8

- docs(cloud-migrate): add Kubernetes to Container Apps migration guidance ([#1568](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1568))

## 1.1.7

- fix(azure-prepare): mandate Active Directory Default in SQL connection strings ([#1937](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1937))

## 1.1.6

- fix(azure-prepare): fix Aspire AddParameter+WithBuildArg guidance for all azd versions ([#1939](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1939))

## 1.1.5

- refactor: support multi-protocol (responses + invocation) in create skill, fix invoke skill and other issues ([#2013](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2013))

## 1.1.4

- chore: support hosted agent v2 in code gen and deploy skill ([#2000](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/2000))

## 1.1.3

- Refactor aks troubleshoot paths ([#1987](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1987))

## 1.1.2

- fix: clarify output directory naming to use workspace root basename ([#1990](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1990))

## 1.1.1

- Tweak instructions to resolve synk high risks ([#1988](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1988))

## 1.1.0

- Add Gulp build system with NBGV versioning ([#1968](https://github.com/microsoft/GitHub-Copilot-for-Azure/pull/1968))
