#!/usr/bin/env bash
# wait-for-text.sh — poll a tmux pane until a regex or fixed string appears.
# Supports both -S (socket path) and -L (socket name) for selecting the tmux server.
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage: wait-for-text.sh -t target -p pattern [options]

Poll a tmux pane for text and exit when found.

Options:
  -t, --target        tmux target (session:window.pane), required
  -p, --pattern       regex pattern to look for, required
  -S, --socket-path   tmux socket path (passed to tmux -S)
  -L, --socket-name   tmux socket name (passed to tmux -L)
  -F, --fixed         treat pattern as a fixed string (grep -F)
  -T, --timeout       seconds to wait (integer, default: 15)
  -i, --interval      poll interval in seconds (default: 0.3)
  -l, --lines         number of history lines to inspect (integer, default: 1000)
  -h, --help          show this help
USAGE
}

target=""
pattern=""
socket_path=""
socket_name=""
grep_flag="-E"
timeout=15
interval=0.3
lines=1000

while [[ $# -gt 0 ]]; do
  case "$1" in
    -t|--target)       target="${2-}";      shift 2 ;;
    -p|--pattern)      pattern="${2-}";     shift 2 ;;
    -S|--socket-path)  socket_path="${2-}"; shift 2 ;;
    -L|--socket-name)  socket_name="${2-}"; shift 2 ;;
    -F|--fixed)        grep_flag="-F";      shift   ;;
    -T|--timeout)      timeout="${2-}";     shift 2 ;;
    -i|--interval)     interval="${2-}";    shift 2 ;;
    -l|--lines)        lines="${2-}";       shift 2 ;;
    -h|--help)         usage; exit 0        ;;
    *) echo "Unknown option: $1" >&2; usage; exit 1 ;;
  esac
done

[[ -z "$target" || -z "$pattern" ]] && { echo "target and pattern are required" >&2; usage; exit 1; }
[[ "$timeout" =~ ^[0-9]+$ ]] || { echo "timeout must be an integer" >&2; exit 1; }
[[ "$lines"   =~ ^[0-9]+$ ]] || { echo "lines must be an integer" >&2;   exit 1; }
command -v tmux >/dev/null 2>&1 || { echo "tmux not found in PATH" >&2;  exit 1; }

# Build the tmux base command
tmux_cmd=(tmux)
if [[ -n "$socket_path" ]]; then
  tmux_cmd+=(-S "$socket_path")
elif [[ -n "$socket_name" ]]; then
  tmux_cmd+=(-L "$socket_name")
fi

deadline=$(( $(date +%s) + timeout ))

while true; do
  pane_text="$("${tmux_cmd[@]}" capture-pane -p -J -t "$target" -S "-${lines}" 2>/dev/null || true)"

  if printf '%s\n' "$pane_text" | grep $grep_flag -- "$pattern" >/dev/null 2>&1; then
    exit 0
  fi

  if (( $(date +%s) >= deadline )); then
    echo "Timed out after ${timeout}s waiting for pattern: $pattern" >&2
    echo "Last ${lines} lines from $target:" >&2
    printf '%s\n' "$pane_text" >&2
    exit 1
  fi

  sleep "$interval"
done
