#!/usr/bin/env bash
# find-sessions.sh — list tmux sessions on one or all sockets.
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage: find-sessions.sh [-L socket-name | -S socket-path | -A] [-q pattern]

List tmux sessions on a socket (default tmux socket if none provided).

Options:
  -L, --socket-name   tmux socket name (passed to tmux -L)
  -S, --socket-path   tmux socket path (passed to tmux -S)
  -A, --all           scan all sockets under CLAUDE_TMUX_SOCKET_DIR
  -q, --query         case-insensitive substring to filter session names
  -h, --help          show this help

Environment:
  CLAUDE_TMUX_SOCKET_DIR   socket directory used with --all (default: /tmp/claude-tmux-sockets)
USAGE
}

socket_name=""
socket_path=""
query=""
scan_all=false
socket_dir="${CLAUDE_TMUX_SOCKET_DIR:-${TMPDIR:-/tmp}/claude-tmux-sockets}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    -L|--socket-name) socket_name="${2-}"; shift 2 ;;
    -S|--socket-path) socket_path="${2-}"; shift 2 ;;
    -A|--all)         scan_all=true;       shift   ;;
    -q|--query)       query="${2-}";       shift 2 ;;
    -h|--help)        usage; exit 0        ;;
    *) echo "Unknown option: $1" >&2; usage; exit 1 ;;
  esac
done

if [[ "$scan_all" == true && ( -n "$socket_name" || -n "$socket_path" ) ]]; then
  echo "Cannot combine --all with -L or -S" >&2; exit 1
fi
if [[ -n "$socket_name" && -n "$socket_path" ]]; then
  echo "Use either -L or -S, not both" >&2; exit 1
fi

command -v tmux >/dev/null 2>&1 || { echo "tmux not found in PATH" >&2; exit 1; }

list_sessions() {
  local label="$1"; shift
  local tmux_cmd=(tmux "$@")
  local sessions

  if ! sessions="$("${tmux_cmd[@]}" list-sessions \
        -F '#{session_name}\t#{session_attached}\t#{session_created_string}' 2>/dev/null)"; then
    echo "No tmux server found on $label" >&2
    return 1
  fi

  [[ -n "$query" ]] && sessions="$(printf '%s\n' "$sessions" | grep -i -- "$query" || true)"

  if [[ -z "$sessions" ]]; then
    echo "No sessions found on $label"
    return 0
  fi

  echo "Sessions on $label:"
  while IFS=$'\t' read -r name attached created; do
    local status=$([[ "$attached" == "1" ]] && echo "attached" || echo "detached")
    printf '  - %s (%s, started %s)\n' "$name" "$status" "$created"
  done <<< "$sessions"
}

if [[ "$scan_all" == true ]]; then
  [[ -d "$socket_dir" ]] || { echo "Socket directory not found: $socket_dir" >&2; exit 1; }

  shopt -s nullglob
  sockets=("$socket_dir"/*)
  shopt -u nullglob

  [[ "${#sockets[@]}" -gt 0 ]] || { echo "No sockets found under $socket_dir" >&2; exit 1; }

  exit_code=0
  for sock in "${sockets[@]}"; do
    [[ -S "$sock" ]] || continue
    list_sessions "socket '$sock'" -S "$sock" || exit_code=$?
  done
  exit "$exit_code"
fi

tmux_args=()
socket_label="default socket"

if [[ -n "$socket_name" ]]; then
  tmux_args=(-L "$socket_name")
  socket_label="socket name '$socket_name'"
elif [[ -n "$socket_path" ]]; then
  tmux_args=(-S "$socket_path")
  socket_label="socket path '$socket_path'"
fi

list_sessions "$socket_label" "${tmux_args[@]}"
