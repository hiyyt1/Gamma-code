# Custom Transport | 自定义传输层

**官方文档**: https://docs.nestjs.com/microservices/custom-transport

## Instructions

Implement a custom transporter.

## Key Concepts
- Implement a custom transporter.
- Use decorators to declare behavior
- Keep providers and controllers focused

## Example
```ts
// example(): 示例函数，演示核心用法
function example() {
  return 'custom-transport'
}
```
