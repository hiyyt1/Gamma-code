---
name: sentry-sdk-setup
description: Set up Sentry in any language or framework. Detects the user's platform and loads the right SDK skill. Use when asked to add Sentry, install an SDK, or set up error monitoring in a project.
license: Apache-2.0
role: router
---

> [All Skills](../../SKILL_TREE.md)

# Sentry SDK Setup

Set up Sentry error monitoring, tracing, and session replay in any language or framework. This page helps you find the right SDK skill for your project.

## Start Here — Read This Before Doing Anything

**Do not skip this section.** Do not assume which SDK the user needs based on their project files. Do not start installing packages or creating config files until you have confirmed the user's intent.

1. **Detect the platform** from project files (`package.json`, `go.mod`, `requirements.txt`, `Gemfile`, `*.csproj`, `build.gradle`, etc.).
2. **Tell the user what you found** and which SDK you recommend.
3. **Wait for confirmation** before reading the skill and proceeding.

Each SDK skill contains its own detection logic, prerequisites, and step-by-step configuration. Trust the skill — read it carefully and follow it. Do not improvise or take shortcuts.

---

## SDK Skills

| Platform | Skill |
|---|---|
| Android | [`sentry-android-sdk`](../sentry-android-sdk/SKILL.md) |
| browser JavaScript | [`sentry-browser-sdk`](../sentry-browser-sdk/SKILL.md) |
| Cloudflare Workers and Pages | [`sentry-cloudflare-sdk`](../sentry-cloudflare-sdk/SKILL.md) |
| Apple platforms (iOS, macOS, tvOS, watchOS, visionOS) | [`sentry-cocoa-sdk`](../sentry-cocoa-sdk/SKILL.md) |
| .NET | [`sentry-dotnet-sdk`](../sentry-dotnet-sdk/SKILL.md) |
| Elixir | [`sentry-elixir-sdk`](../sentry-elixir-sdk/SKILL.md) |
| Go | [`sentry-go-sdk`](../sentry-go-sdk/SKILL.md) |
| NestJS | [`sentry-nestjs-sdk`](../sentry-nestjs-sdk/SKILL.md) |
| Next.js | [`sentry-nextjs-sdk`](../sentry-nextjs-sdk/SKILL.md) |
| Node.js, Bun, and Deno | [`sentry-node-sdk`](../sentry-node-sdk/SKILL.md) |
| PHP | [`sentry-php-sdk`](../sentry-php-sdk/SKILL.md) |
| Python | [`sentry-python-sdk`](../sentry-python-sdk/SKILL.md) |
| Flutter and Dart | [`sentry-flutter-sdk`](../sentry-flutter-sdk/SKILL.md) |
| React Native and Expo | [`sentry-react-native-sdk`](../sentry-react-native-sdk/SKILL.md) |
| React | [`sentry-react-sdk`](../sentry-react-sdk/SKILL.md) |
| React Router Framework | [`sentry-react-router-framework-sdk`](../sentry-react-router-framework-sdk/SKILL.md) |
| TanStack Start React | [`sentry-tanstack-start-sdk`](../sentry-tanstack-start-sdk/SKILL.md) |
| Ruby | [`sentry-ruby-sdk`](../sentry-ruby-sdk/SKILL.md) |
| Svelte and SvelteKit | [`sentry-svelte-sdk`](../sentry-svelte-sdk/SKILL.md) |

### Platform Detection Priority

When multiple SDKs could match, prefer the more specific one:

- **Android** (`build.gradle` with android plugin) → `sentry-android-sdk`
- **Cloudflare** (`wrangler.toml` or `wrangler.jsonc`) → `sentry-cloudflare-sdk` over `sentry-node-sdk`
- **NestJS** (`@nestjs/core`) → `sentry-nestjs-sdk` over `sentry-node-sdk`
- **Next.js** → `sentry-nextjs-sdk` over `sentry-react-sdk` or `sentry-node-sdk`
- **React Router Framework** (`@sentry/react-router` or `@react-router/*`) → `sentry-react-router-framework-sdk` over `sentry-react-sdk`
- **TanStack Start React** (`@tanstack/react-start`) → `sentry-tanstack-start-sdk` over `sentry-react-sdk`
- **Flutter** (`pubspec.yaml` with `flutter:` dependency or `sentry_flutter`) → `sentry-flutter-sdk`
- **React Native** → `sentry-react-native-sdk` over `sentry-react-sdk`
- **PHP** with Laravel or Symfony → `sentry-php-sdk`
- **Elixir** (`mix.exs` detected) → `sentry-elixir-sdk`
- **Node.js / Bun / Deno** without a specific framework → `sentry-node-sdk`
- **Browser JS** (vanilla, jQuery, static sites) → `sentry-browser-sdk`
- **No match** → direct user to [Sentry Docs](https://docs.sentry.io/platforms/)

## Quick Lookup

Match your project to a skill by keywords.

| Keywords | Skill |
|---|---|
| android, kotlin, java, jetpack compose | [`sentry-android-sdk`](../sentry-android-sdk/SKILL.md) |
| browser, vanilla js, javascript, jquery, cdn, wordpress, static site | [`sentry-browser-sdk`](../sentry-browser-sdk/SKILL.md) |
| cloudflare, cloudflare workers, cloudflare pages, wrangler, durable objects, d1 | [`sentry-cloudflare-sdk`](../sentry-cloudflare-sdk/SKILL.md) |
| ios, macos, swift, cocoa, tvos, watchos, visionos, swiftui, uikit | [`sentry-cocoa-sdk`](../sentry-cocoa-sdk/SKILL.md) |
| .net, csharp, c#, asp.net, maui, wpf, winforms, blazor, azure functions | [`sentry-dotnet-sdk`](../sentry-dotnet-sdk/SKILL.md) |
| go, golang, gin, echo, fiber | [`sentry-go-sdk`](../sentry-go-sdk/SKILL.md) |
| elixir, phoenix, plug, oban | [`sentry-elixir-sdk`](../sentry-elixir-sdk/SKILL.md) |
| nestjs, nest | [`sentry-nestjs-sdk`](../sentry-nestjs-sdk/SKILL.md) |
| nextjs, next.js, next | [`sentry-nextjs-sdk`](../sentry-nextjs-sdk/SKILL.md) |
| node, nodejs, node.js, bun, deno, express, fastify, koa, hapi | [`sentry-node-sdk`](../sentry-node-sdk/SKILL.md) |
| php, laravel, symfony | [`sentry-php-sdk`](../sentry-php-sdk/SKILL.md) |
| python, django, flask, fastapi, celery, starlette | [`sentry-python-sdk`](../sentry-python-sdk/SKILL.md) |
| flutter, dart, pubspec | [`sentry-flutter-sdk`](../sentry-flutter-sdk/SKILL.md) |
| react native, expo | [`sentry-react-native-sdk`](../sentry-react-native-sdk/SKILL.md) |
| react, react router, tanstack, redux, vite | [`sentry-react-sdk`](../sentry-react-sdk/SKILL.md) |
| react-router framework, @sentry/react-router, @react-router/dev, react-router reveal | [`sentry-react-router-framework-sdk`](../sentry-react-router-framework-sdk/SKILL.md) |
| tanstack start, tanstack react start, @tanstack/react-start, tanstackstart-react | [`sentry-tanstack-start-sdk`](../sentry-tanstack-start-sdk/SKILL.md) |
| ruby, rails, sinatra, sidekiq, rack | [`sentry-ruby-sdk`](../sentry-ruby-sdk/SKILL.md) |
| svelte, sveltekit | [`sentry-svelte-sdk`](../sentry-svelte-sdk/SKILL.md) |

---

## Finding the DSN

If the user doesn't have their DSN, guide them to find it:

1. Open the Sentry project settings page: `https://sentry.io/settings/projects/`
2. Select the project
3. Click **"Client Keys (DSN)"** in the left sidebar
4. Copy the DSN

You can help the user open the page directly:
```bash
open https://sentry.io/settings/projects/        # macOS
xdg-open https://sentry.io/settings/projects/    # Linux
start https://sentry.io/settings/projects/        # Windows
```

> **Note:** The DSN is public and safe to include in source code. It is not a secret — it only identifies where to send events.

---

Looking for workflows or feature configuration instead? See the [full Skill Tree](../../SKILL_TREE.md).
