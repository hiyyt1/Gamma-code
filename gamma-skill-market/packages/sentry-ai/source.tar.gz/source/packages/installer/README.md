# @sentry/agent-plugin

Install the [Sentry plugin](https://github.com/getsentry/sentry-for-ai) into your AI
coding assistants.

The plugin teaches your assistant Sentry — how to set it up in any project, how to find
and fix production issues, and how to configure alerts, AI monitoring, and more.
This package detects which assistants you have installed and wires the plugin into each
one for you.

Supports **Claude Code**, **Codex**, **Cursor**, and **Grok**.

```bash
npx @sentry/agent-plugin install
```

<picture> <source media="(prefers-color-scheme: dark)" srcset="assets/demo-dark.gif">
<img src="assets/demo-light.gif" alt="Installing the Sentry plugin with npx @sentry/agent-plugin install">
</picture>

This detects the AI coding tools on your machine, lets you choose which ones to set up,
and installs the Sentry plugin into each.
Already have it installed?
The same command updates it to the latest version.

Restart your AI tools afterward to load the plugin.

## Options

```bash
npx @sentry/agent-plugin install                   # interactive — pick which agents to set up
npx @sentry/agent-plugin install "Setup logging"   # copy a custom prompt after installation
npx @sentry/agent-plugin install acme-widgets#abcde12345 # copy an onboarding prompt
npx @sentry/agent-plugin install --no-interactive  # install into every detected agent
```

When an instruction follows `install`, the installer offers to copy a prompt such as
`The Sentry plugin has just been installed. Setup logging` after installation.
Without an instruction, it offers the default get-started prompt.
An argument in the form `org-slug#onboarding-code` generates the getting started prompt
with the organization slug and 10-character alphanumeric run code supplied by Sentry’s
onboarding page, so the agent can report setup progress to that run.
The non-interactive mode is intended for CI and unattended runs and skips this prompt.

## What it installs

For each detected assistant, the installer runs that tool’s native plugin command:

| Assistant | How it’s installed |
| --- | --- |
| Claude Code | `claude plugin install sentry` from the official plugin marketplace |
| Codex | `codex plugin add sentry` from the Sentry plugin marketplace |
| Cursor | Clones [`getsentry/plugin-cursor`](https://github.com/getsentry/plugin-cursor) into `~/.cursor/plugins/local/sentry` |
| Grok | `grok plugin install getsentry/plugin-grok` |

Each per-agent plugin is built and published from the
[`sentry-for-ai`](https://github.com/getsentry/sentry-for-ai) repository, which is the
source of truth for all skills.

## Removing the plugin

```bash
npx @sentry/agent-plugin remove                  # interactive — pick which agents to remove from
npx @sentry/agent-plugin remove --no-interactive # remove from every agent that has it
```

`uninstall` is an alias for `remove`. This only offers agents that currently have the
plugin, and removes the Sentry plugin itself — each tool’s plugin marketplace is left
registered. Restart your AI tools afterward to drop the plugin.

## Requirements

- Node.js 22.13 or newer
- The assistant CLI you want to set up must already be installed and on your `PATH`
- `git` is required for the Cursor install

## License

MIT
